# Orientações para integração do banco de dados

Este repositório contém a aplicação Web/API ASP.NET Core e persistência local SQLite. O arquivo `database/schema-sqlserver.sql` é uma **proposta inicial**, não uma integração SQL Server concluída.

1. Clone o repositório e crie a branch `feature/integracao-banco`.
2. Leia `docs/CONTRATO-API.md`, `docs/INTEGRACAO-BANCO.md` e `database/schema-sqlserver.sql`.
3. Compare o MER/modelo lógico do grupo com os dados usados em `src/FitLife.Api/Program.cs`. Não substitua tabelas sem mapear os endpoints.
4. Configure credenciais fora do Git (variáveis de ambiente ou user-secrets); não comite `.db`, `.env` ou senhas.
5. Implemente a persistência do SGBD escolhido, preservando os contratos da API sempre que possível.
6. Documente o modelo físico, scripts, procedures e triggers exigidos pelo PIM.
7. Execute build e testes de cadastro, login, treinos, evolução e administração. Abra um Pull Request para revisão.

A versão Web com VLibras está no arquivo `wwwroot/index.html`. A aplicação Android nativa e sua integração permanecem pendentes.
