using System.Security.Claims;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.Data.Sqlite;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(o => {
    o.Cookie.Name = "FitLife.Auth"; o.Cookie.HttpOnly = true; o.Cookie.SameSite = SameSiteMode.Lax;
    o.LoginPath = "/"; o.Events.OnRedirectToLogin = ctx => { ctx.Response.StatusCode = 401; return Task.CompletedTask; };
    o.Events.OnRedirectToAccessDenied = ctx => { ctx.Response.StatusCode = 403; return Task.CompletedTask; };
});
builder.Services.AddAuthorization(o => o.AddPolicy("admin",p => p.RequireRole("admin")));
var dbPath = Environment.GetEnvironmentVariable("FITLIFE_DB") ?? Path.Combine(builder.Environment.ContentRootPath, "fitlife.db");
var cs = new SqliteConnectionStringBuilder { DataSource = dbPath, ForeignKeys = true }.ToString();
using (var db = new SqliteConnection(cs)) {
    db.Open();
    var cmd = db.CreateCommand(); cmd.CommandText = """
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'student' CHECK(role IN ('student','admin')), height REAL NOT NULL DEFAULT 0, weight REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS exercises (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT NOT NULL, minutes INTEGER NOT NULL, calories INTEGER NOT NULL, description TEXT NOT NULL DEFAULT '');
    CREATE TABLE IF NOT EXISTS workouts (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, exercise_id INTEGER NOT NULL REFERENCES exercises(id), performed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE INDEX IF NOT EXISTS idx_workouts_user ON workouts(user_id,performed_at);
    """; cmd.ExecuteNonQuery();
    cmd.CommandText = "SELECT COUNT(*) FROM exercises";
    if (Convert.ToInt64(cmd.ExecuteScalar()) == 0) {
        foreach (var ex in new[] {("Treino de força","Força",45,280,"Musculação para corpo inteiro"),("Hipertrofia superior","Força",50,320,"Membros superiores"),("Corrida intervalada","Cardio",30,300,"Caminhada e corrida"),("Bike indoor","Cardio",35,260,"Bicicleta ergométrica"),("Mobilidade funcional","Mobilidade",20,100,"Mobilidade articular"),("Alongamento guiado","Alongamento",15,65,"Flexibilidade")}) {
            Run(db,"INSERT INTO exercises(title,category,minutes,calories,description) VALUES (@a,@b,@c,@d,@e)", ("@a",ex.Item1),("@b",ex.Item2),("@c",ex.Item3),("@d",ex.Item4),("@e",ex.Item5));
        }
    }
    var adminPass = Environment.GetEnvironmentVariable("FITLIFE_ADMIN_PASSWORD");
    if (!string.IsNullOrWhiteSpace(adminPass) && adminPass.Length >= 8) {
        var adminEmail = Environment.GetEnvironmentVariable("FITLIFE_ADMIN_EMAIL") ?? "admin@fitlife.local";
        Run(db,"INSERT OR IGNORE INTO users(name,email,password,role) VALUES ('Administrador',@email,@password,'admin')",("@email",adminEmail),("@password",Hash(adminPass)));
    }
}
var app = builder.Build();
app.Use(async (ctx,next) => {ctx.Response.Headers["X-Content-Type-Options"]="nosniff";ctx.Response.Headers["X-Frame-Options"]="DENY";await next();});
app.UseDefaultFiles();app.UseStaticFiles();app.UseAuthentication();app.UseAuthorization();
SqliteConnection Open() { var db = new SqliteConnection(cs); db.Open(); return db; }
int UserId(ClaimsPrincipal p) => int.Parse(p.FindFirstValue(ClaimTypes.NameIdentifier)!);
object UserDto(SqliteDataReader r) => new {id=r.GetInt32(0),name=r.GetString(1),email=r.GetString(2),role=r.GetString(3),height=r.GetDouble(4),weight=r.GetDouble(5)};
async Task SignIn(HttpContext ctx,int id,string role) => await ctx.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(new ClaimsIdentity(new[]{new Claim(ClaimTypes.NameIdentifier,id.ToString()),new Claim(ClaimTypes.Role,role)},CookieAuthenticationDefaults.AuthenticationScheme)));
app.MapGet("/api/me",(ClaimsPrincipal p) => { if(p.Identity?.IsAuthenticated!=true)return Results.Ok(new {user=(object?)null});using var db=Open();using var r=Query(db,"SELECT id,name,email,role,height,weight FROM users WHERE id=@id",("@id",UserId(p)));return Results.Ok(new {user=r.Read()?UserDto(r):null});});
app.MapPost("/api/register",async (HttpContext ctx,Credentials d) => {var name=(d.name??"").Trim();var email=(d.email??"").Trim().ToLowerInvariant();if(name.Length<2||!email.Contains('@')||(d.password??"").Length<8)return Results.BadRequest(new {error="Nome, e-mail e senha de 8 caracteres são obrigatórios."});using var db=Open();try {Run(db,"INSERT INTO users(name,email,password,role) VALUES(@name,@email,@password,'student')",("@name",name),("@email",email),("@password",Hash(d.password!)));await SignIn(ctx,Convert.ToInt32(new SqliteCommand("SELECT last_insert_rowid();", db).ExecuteScalar()),"student");return Results.Created("/api/me",new {ok=true});}catch(SqliteException ex) when(ex.SqliteErrorCode==19){return Results.Conflict(new {error="E-mail já cadastrado."});}});
app.MapPost("/api/login",async (HttpContext ctx,Credentials d) => {using var db=Open();using var r=Query(db,"SELECT id,password,role FROM users WHERE email=@email",("@email",(d.email??"").Trim().ToLowerInvariant()));if(!r.Read()||!Verify(d.password??"",r.GetString(1)))return Results.Json(new {error="Credenciais inválidas."},statusCode:401);int id=r.GetInt32(0);string role=r.GetString(2);await SignIn(ctx,id,role);return Results.Ok(new {ok=true});});
app.MapPost("/api/logout",async (HttpContext ctx) => {await ctx.SignOutAsync();return Results.Ok(new {ok=true});});
app.MapGet("/api/exercises",() => {using var db=Open();using var r=Query(db,"SELECT id,title,category,minutes,calories,description FROM exercises ORDER BY category,title");var items=new List<object>();while(r.Read())items.Add(new {id=r.GetInt32(0),title=r.GetString(1),category=r.GetString(2),minutes=r.GetInt32(3),calories=r.GetInt32(4),description=r.GetString(5)});return Results.Ok(new {items});}).RequireAuthorization();
app.MapPost("/api/workouts",(ClaimsPrincipal p,WorkoutRequest d) => {using var db=Open();using var r=Query(db,"SELECT id FROM exercises WHERE id=@id",("@id",d.exercise_id));if(!r.Read())return Results.NotFound(new {error="Exercício não encontrado."});r.Close();Run(db,"INSERT INTO workouts(user_id,exercise_id) VALUES(@user,@exercise)",("@user",UserId(p)),("@exercise",d.exercise_id));return Results.Created("/api/stats",new {ok=true});}).RequireAuthorization();
app.MapGet("/api/stats",(ClaimsPrincipal p) => {using var db=Open();using var r=Query(db,"SELECT w.id,w.performed_at,e.title,e.category,e.minutes,e.calories FROM workouts w JOIN exercises e ON e.id=w.exercise_id WHERE w.user_id=@id ORDER BY w.performed_at DESC,w.id DESC",("@id",UserId(p)));var history=new List<object>();var days=new HashSet<string>();int total=0,minutes=0,calories=0;while(r.Read()){total++;var at=r.GetString(1);days.Add(at[..10]);minutes+=r.GetInt32(4);calories+=r.GetInt32(5);if(history.Count<30)history.Add(new {id=r.GetInt32(0),performed_at=at,title=r.GetString(2),category=r.GetString(3),minutes=r.GetInt32(4),calories=r.GetInt32(5)});}var day=DateTime.UtcNow.Date;if(!days.Contains(day.ToString("yyyy-MM-dd")))day=day.AddDays(-1);int streak=0;while(days.Contains(day.ToString("yyyy-MM-dd"))){streak++;day=day.AddDays(-1);}return Results.Ok(new {total,minutes,calories,streak,history,achievements=new[]{new {name="Primeiro passo",unlocked=total>=1,target="1 treino"},new {name="Foco total",unlocked=total>=5,target="5 treinos"},new {name="Constância",unlocked=total>=10,target="10 treinos"}}});}).RequireAuthorization();
app.MapMethods("/api/profile",new[]{"PATCH"},(ClaimsPrincipal p,Profile d) => {if((d.name??"").Trim().Length<2||d.height<0||d.height>250||d.weight<0||d.weight>500)return Results.BadRequest(new {error="Dados do perfil inválidos."});using var db=Open();Run(db,"UPDATE users SET name=@name,height=@height,weight=@weight WHERE id=@id",("@name",d.name!.Trim()),("@height",d.height),("@weight",d.weight),("@id",UserId(p)));return Results.Ok(new {ok=true});}).RequireAuthorization();
app.MapGet("/api/admin/summary",() => {using var db=Open();int Count(string sql){using var cmd=db.CreateCommand();cmd.CommandText=sql;return Convert.ToInt32(cmd.ExecuteScalar());}var students=Count("SELECT COUNT(*) FROM users WHERE role='student'");var workouts=Count("SELECT COUNT(*) FROM workouts");var exercises=Count("SELECT COUNT(*) FROM exercises");using var r=Query(db,"SELECT u.id,u.name,u.email,u.created_at,COUNT(w.id) FROM users u LEFT JOIN workouts w ON w.user_id=u.id WHERE u.role='student' GROUP BY u.id ORDER BY u.created_at DESC");var users=new List<object>();while(r.Read())users.Add(new {id=r.GetInt32(0),name=r.GetString(1),email=r.GetString(2),created_at=r.GetString(3),workouts=Convert.ToInt32(r.GetInt64(4))});return Results.Ok(new {students,workouts,exercises,users});}).RequireAuthorization("admin");
app.MapPost("/api/admin/exercises",(Exercise d) => {if(string.IsNullOrWhiteSpace(d.title)||string.IsNullOrWhiteSpace(d.category)||d.minutes<1||d.minutes>300||d.calories<0||d.calories>3000)return Results.BadRequest(new {error="Dados do exercício inválidos."});using var db=Open();Run(db,"INSERT INTO exercises(title,category,minutes,calories,description) VALUES(@title,@category,@minutes,@calories,@description)",("@title",d.title.Trim()),("@category",d.category.Trim()),("@minutes",d.minutes),("@calories",d.calories),("@description",d.description??""));return Results.Created("/api/exercises",new {ok=true});}).RequireAuthorization("admin");
app.Run();
static SqliteDataReader Query(SqliteConnection db,string sql,params (string,object?)[] args){var c=db.CreateCommand();c.CommandText=sql;foreach(var (k,v) in args)c.Parameters.AddWithValue(k,v??DBNull.Value);return c.ExecuteReader();}
static void Run(SqliteConnection db,string sql,params (string,object?)[] args){using var c=db.CreateCommand();c.CommandText=sql;foreach(var (k,v) in args)c.Parameters.AddWithValue(k,v??DBNull.Value);c.ExecuteNonQuery();}
static string Hash(string password){var salt=RandomNumberGenerator.GetBytes(16);var key=Rfc2898DeriveBytes.Pbkdf2(password,salt,120000,HashAlgorithmName.SHA256,32);return Convert.ToBase64String(salt)+":"+Convert.ToBase64String(key);}
static bool Verify(string password,string stored){try{var parts=stored.Split(':');var key=Rfc2898DeriveBytes.Pbkdf2(password,Convert.FromBase64String(parts[0]),120000,HashAlgorithmName.SHA256,32);return CryptographicOperations.FixedTimeEquals(key,Convert.FromBase64String(parts[1]));}catch{return false;}}
record Credentials(string? name,string? email,string? password);
record WorkoutRequest(int exercise_id);
record Profile(string? name,double height,double weight);
record Exercise(string title,string category,int minutes,int calories,string? description);
