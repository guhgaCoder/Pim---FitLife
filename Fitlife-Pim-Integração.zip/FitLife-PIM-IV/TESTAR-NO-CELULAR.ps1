Write-Host '=== FitLife: diagnostico de acesso local ===' -ForegroundColor Cyan
Write-Host 'IPs IPv4 do computador (identifique o adaptador Wi-Fi ativo):'
Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | Select-Object InterfaceAlias,IPAddress | Format-Table -AutoSize
Write-Host 'Verificando o servidor local em http://localhost:5080 ...'
try {
    $r = Invoke-WebRequest -Uri 'http://localhost:5080' -TimeoutSec 5 -UseBasicParsing
    Write-Host "Servidor respondeu HTTP $($r.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host 'Servidor indisponivel. Inicie na pasta src\FitLife.Api: dotnet run --urls "http://0.0.0.0:5080"' -ForegroundColor Yellow
}
Write-Host 'No celular: http://IP_DO_WIFI:5080 (substitua pelo IPv4 acima).'
Write-Host 'Use apenas Wi-Fi privado e confiavel. Nao exponha a porta na internet.'
