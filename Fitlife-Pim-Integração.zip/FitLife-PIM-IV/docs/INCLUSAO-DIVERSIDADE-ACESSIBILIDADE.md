# Responsabilidade social, diversidade e inclusão — FitLife PIM IV

## Relação com a disciplina EAD

A disciplina **Relações étnico-raciais e afrodescendência** orienta a análise de como o FitLife pode combater discriminação, valorizar diversidade, disponibilizar recursos inclusivos, ampliar acessibilidade e promover cidadania. O documento de orientação do PIM prevê esses aspectos na seção **2.6** e sua integração interdisciplinar na seção **5.8**.

## Implementações presentes na versão 1.0.3

- Página **Acessibilidade** na navegação do aluno e do administrador.
- Preferências de **texto ampliado**, **alto contraste** e **redução de animações**, persistidas localmente no navegador.
- Link **Pular para o conteúdo**, foco visível, rótulo acessível no menu, indicação da página ativa, fechamento do menu com Esc e região de avisos `aria-live`.
- Texto informativo contra discriminação, com compromisso de acolhimento e orientações para relatar barreiras.
- As conquistas existentes são baseadas no registro de treinos, não em raça, gênero ou outras características pessoais.

## VLibras

O usuário relatou que adicionou VLibras **na cópia local**. O widget não consta no ZIP-base 1.0.2 utilizado nesta atualização; por isso **não foi reinserido automaticamente** para evitar duplicação ou substituir a integração existente. Após mesclar esta atualização com sua cópia local, confira se o VLibras continua carregando e se não cobre os botões no celular. O VLibras não garante acessibilidade integral e exige testes com usuários.

## Propostas futuras (não implementadas)

- Canal de denúncia com privacidade, tratamento e encaminhamento por equipe responsável; política de moderação contra ofensas e discriminação.
- Revisão de linguagem e representatividade de imagens e materiais, sem estereótipos étnico-raciais.
- Validação com pessoas com deficiência, incluindo usuários de leitores de tela e pessoas surdas.
- Auditoria de contraste, navegação por teclado, formulários e mensagens, alinhada às WCAG 2.2.
- No Android nativo: suporte a TalkBack, `contentDescription`, escalonamento de fontes, foco e acessibilidade dos formulários XML/Java.
- Proteção de dados pessoais e sensíveis, consentimento adequado e controles de acesso conforme LGPD.

## Evidências para o relatório PIM

Registrar capturas da página Acessibilidade e seus estados, testes de navegação por teclado e celular, descrição da inclusão no capítulo 2.6 e contribuição da disciplina no capítulo 5.8. Não afirmar testes com usuários ou conformidade integral com WCAG se não foram realizados.
