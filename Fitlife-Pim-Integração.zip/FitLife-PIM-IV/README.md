# FitLife — PIM IV UNIP | Entrega de código-fonte inicial em .NET

## O que foi incluído
Projeto ASP.NET Core 8, frontend HTML/CSS/JavaScript modernizado, API JSON, login e cadastro, portal do aluno, treinos, evolução, conquistas, perfil, painel administrativo, banco SQLite inicial e script SQL Server de referência.

**Status honesto:** os arquivos foram criados, mas não compilados nem executados neste ambiente porque o SDK .NET não está instalado. Esta entrega NÃO é certificada como 100% funcional. A integração Android, o banco definitivo do colega e os demais itens acadêmicos estão pendentes (ver `docs/PIM-RASTREABILIDADE.md`).

## Requisitos
- SDK .NET 8 (ou ambiente compatível com o alvo net8.0)
- Internet no primeiro `dotnet restore` para obter Microsoft.Data.Sqlite 8.0.11

## Executar (Windows PowerShell)
```powershell
cd src/FitLife.Api
$env:FITLIFE_ADMIN_EMAIL="admin@fitlife.local"
$env:FITLIFE_ADMIN_PASSWORD="TroquePorUmaSenhaForte123!"
dotnet restore
dotnet run --urls http://localhost:5080
```
Acesse http://localhost:5080. Para alunos, clique em **Criar conta**. O administrador é criado no primeiro início com as variáveis de ambiente acima. **Não use credenciais demonstrativas em produção.**

## Executar (Linux/macOS)
```bash
cd src/FitLife.Api
export FITLIFE_ADMIN_EMAIL=admin@fitlife.local
export FITLIFE_ADMIN_PASSWORD='TroquePorUmaSenhaForte123!'
dotnet restore
dotnet run --urls http://localhost:5080
```

## Banco de dados
Por padrão o arquivo `fitlife.db` é criado no diretório do projeto Web. Pode ser alterado por `FITLIFE_DB`. O banco inicial é SQLite e não deve ser confundido com a implementação final SQL Server. O arquivo `database/schema-sqlserver.sql` é uma proposta de modelo físico e scripts acadêmicos, **não está conectado automaticamente à aplicação**.

## Antes de entregar o PIM
Executar e testar todos os fluxos no computador do grupo; trocar SQLite pelo banco validado; separar serviços/repositórios; adicionar proteção CSRF para autenticação por cookie, rate limiting, HTTPS, gestão de segredo e logs; criar API autenticada para Android; produzir MER e diagramas, documentação de sprints, DevOps e evidências. Não publicar este MVP como produto de produção.

## Correções da revisão 1.0.1
- Corrigido erro CS1061 de `SqliteConnection.LastInsertRowId` por consulta SQLite `SELECT last_insert_rowid()` na mesma conexão.
- Ajustada leitura de `COUNT(w.id)` para inteiro de 64 bits antes da conversão para inteiro de 32 bits.
- Verificações locais: inspeção do código e sintaxe de JavaScript. **Não foi possível compilar ou executar a API neste ambiente por ausência do SDK .NET**. Rode `dotnet build` e `dotnet run` no computador para validar.


## Atualização v1.0.3 — Inclusão e acessibilidade

Página Acessibilidade com texto ampliado, alto contraste, redução de animações e melhorias de navegação por teclado. Consulte `docs/INCLUSAO-DIVERSIDADE-ACESSIBILIDADE.md` e `docs/TESTES-ACESSIBILIDADE.md`. **A integração VLibras adicionada pelo usuário em sua cópia local não consta neste pacote-base**: preserve/mescle o código local ao atualizar. Esta entrega não substitui o projeto Android nativo nem o banco SQL Server do colega.

## Colaboração pelo GitHub
Este pacote inclui `.gitignore`, `CONTRIBUTING.md`, `docs/INTEGRACAO-BANCO.md` e workflow de build em `.github/workflows/dotnet-build.yml`. O workflow será executado no GitHub após publicar; **não foi validado neste ambiente**.

**Atenção:** o VLibras que foi adicionado na cópia local do usuário não consta nesta base. Antes de substituir sua pasta local, compare os arquivos e preserve essa alteração.


## VLibras e integração colaborativa

O widget VLibras está incluído em `src/FitLife.Api/wwwroot/index.html`. Veja `docs/VLibras-INTEGRACAO.md` para testar. Para o colega responsável pelo banco, veja `docs/PASSAGEM-PARA-COLEGA-BANCO.md`. A aplicação Android nativa e a migração definitiva do banco ainda não estão concluídas.
