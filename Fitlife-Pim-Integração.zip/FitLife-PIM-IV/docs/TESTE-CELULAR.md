# FitLife PIM IV — teste da versão Web no celular

## Pré-requisitos
- Computador Windows com .NET 8 SDK e FitLife funcionando.
- Celular e computador na mesma rede Wi-Fi privada (sem isolamento de clientes).
- Este teste usa HTTP **somente na rede local confiável**. Não exponha a porta na internet nem configure redirecionamento no roteador.

## Iniciar o servidor
No PowerShell, dentro de `src\FitLife.Api`:

```powershell
$env:FITLIFE_ADMIN_EMAIL="admin@fitlife.local"
$env:FITLIFE_ADMIN_PASSWORD="UmaSenhaForteLocal123!"
dotnet run --urls "http://0.0.0.0:5080"
```

`0.0.0.0` indica que o servidor escuta nas interfaces do computador; **não** é o endereço a digitar no celular.

## Descobrir o endereço correto
Em **outro** terminal PowerShell no computador:

```powershell
ipconfig
```

Procure o **Endereço IPv4** do adaptador Wi-Fi em uso (por exemplo, `192.168.1.105`). No navegador do celular, digite `http://SEU_IP:5080` substituindo pelo IP real.

## Se não abrir
1. Confirme que `http://localhost:5080` funciona no computador.
2. Teste `http://SEU_IP:5080` no navegador **do computador**.
3. Confira se ambos estão no mesmo Wi-Fi; desative VPNs que impeçam acesso à rede local.
4. Verifique se o firewall permite o aplicativo/porta **apenas em redes privadas**. Evite desligar o firewall inteiro.
5. Algumas redes de convidados ou universidades bloqueiam comunicação entre dispositivos; use uma rede doméstica confiável.

## Checklist funcional
- [ ] Página carrega sem barras horizontais nem botões cortados.
- [ ] Cadastro de aluno e login funcionam.
- [ ] Navegação Início / Treinos / Evolução / Perfil funciona.
- [ ] Registro de treino atualiza estatísticas e conquistas.
- [ ] Perfil pode ser atualizado.
- [ ] Ao atualizar a página, os dados permanecem.
- [ ] Conta comum não consegue acessar endpoints administrativos (403).
- [ ] Painel administrativo funciona apenas com conta admin.

## Limites desta etapa
Acesso pelo navegador **não equivale a um aplicativo Android nativo**. O documento Mobile fornecido descreve Android Studio + Java + XML, com login, menu e telas de Cadastro/Consulta/Configurações. Essa implementação é uma etapa separada. A API atual usa cookie para o portal Web; autenticação Mobile e HTTPS devem ser projetados antes de acesso externo.
