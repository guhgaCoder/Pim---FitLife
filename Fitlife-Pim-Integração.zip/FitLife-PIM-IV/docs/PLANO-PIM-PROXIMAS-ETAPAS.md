# Plano de continuidade — FitLife PIM IV

Fonte acadêmica: `sugestao_desenvolvimento_capitulos_PIM_IV-1.pdf` e `Projeto_Completo_Desenvolvimento_Mobile_Roteiros_1_2_3_4.docx` enviados pelo grupo.

## Implementado na base Web (ainda sujeito a testes de integração)
- ASP.NET Core 8 com interface Web, API e autenticação por cookie.
- Entidades iniciais SQLite: `users`, `exercises`, `workouts`.
- Cadastro/login, consulta de exercícios, registro de treinos, indicadores e perfil.
- Endpoints administrativos para resumo e cadastro de exercícios.

## Ainda necessário para cumprir o escopo documental
1. **Arquitetura:** separar apresentação, regras de negócio e persistência em camadas e aplicar orientação a objetos; diagramar arquitetura e infraestrutura.
2. **Banco:** validar MER, modelo lógico/físico e script com colega; implementar e demonstrar procedures e triggers no SGBD definitivo; testar migração de dados.
3. **Mobile:** Android Studio + Java/XML, com fluxo Login → Menu → Cadastro/Consultar/Configurações/Sair; adaptar ao FitLife e integrar à API. O documento também pede comparação didática com Flutter.
4. **Integração:** especificar e validar contratos Web/Mobile/API/banco; implementar autenticação segura para Mobile, HTTPS e testes de autorização.
5. **DevOps/cloud:** versionamento Git, pipeline CI/CD, proposta de containers/nuvem, monitoramento e implantação segura.
6. **Gestão:** Product Backlog, Sprints, Sprint Backlog, Kanban, cronograma e evidências reais.
7. **Documentação:** capítulos do PIM, diagramas, capturas de tela, acessibilidade/inclusão e conclusões.

## Orientações para integração do banco do colega
Solicitar: SGBD e versão, script DDL, MER, tabelas/colunas/tipos, PK/FK, índices, procedures, triggers, dados de teste, regras de negócio e forma de conexão (sem senhas em arquivos compartilhados). Preservar o contrato REST sempre que possível; alterar a camada de persistência e adicionar testes de regressão.

## Critério de pronto
Não declarar o PIM finalizado até compilar, executar e testar os fluxos Web e Mobile com o banco escolhido, verificar autorização e produzir a documentação exigida.
