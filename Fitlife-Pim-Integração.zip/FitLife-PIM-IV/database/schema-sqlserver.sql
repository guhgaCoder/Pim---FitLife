-- Modelo físico proposto para SQL Server. Não executar sobre banco do colega sem comparar o MER.
CREATE TABLE Usuarios (Id INT IDENTITY PRIMARY KEY, Nome NVARCHAR(150) NOT NULL, Email NVARCHAR(255) NOT NULL UNIQUE, SenhaHash NVARCHAR(255) NOT NULL, Perfil VARCHAR(15) NOT NULL CHECK (Perfil IN ('student','admin')), Altura DECIMAL(5,1) NOT NULL DEFAULT 0, Peso DECIMAL(5,1) NOT NULL DEFAULT 0, CriadoEm DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME());
CREATE TABLE Exercicios (Id INT IDENTITY PRIMARY KEY, Titulo NVARCHAR(150) NOT NULL, Categoria NVARCHAR(80) NOT NULL, DuracaoMin INT NOT NULL CHECK (DuracaoMin BETWEEN 1 AND 300), CaloriasEstimadas INT NOT NULL CHECK (CaloriasEstimadas BETWEEN 0 AND 3000), Descricao NVARCHAR(1000) NOT NULL DEFAULT '');
CREATE TABLE Treinos (Id INT IDENTITY PRIMARY KEY, UsuarioId INT NOT NULL REFERENCES Usuarios(Id), ExercicioId INT NOT NULL REFERENCES Exercicios(Id), RealizadoEm DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME());
CREATE INDEX IX_Treinos_Usuario_Data ON Treinos(UsuarioId, RealizadoEm DESC);
GO
-- Exemplo acadêmico de procedure: histórico por aluno
CREATE OR ALTER PROCEDURE dbo.ObterTreinosPorAluno @UsuarioId INT AS BEGIN SET NOCOUNT ON; SELECT t.Id,t.RealizadoEm,e.Titulo,e.DuracaoMin,e.CaloriasEstimadas FROM Treinos t JOIN Exercicios e ON e.Id=t.ExercicioId WHERE t.UsuarioId=@UsuarioId ORDER BY t.RealizadoEm DESC; END;
GO
-- Exemplo acadêmico de trigger de auditoria (para futura integração)
CREATE TABLE AuditoriaTreinos (Id INT IDENTITY PRIMARY KEY, TreinoId INT NOT NULL, UsuarioId INT NOT NULL, RegistradoEm DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME());
GO
CREATE OR ALTER TRIGGER dbo.TRG_Treinos_Auditoria ON dbo.Treinos AFTER INSERT AS BEGIN SET NOCOUNT ON; INSERT INTO dbo.AuditoriaTreinos(TreinoId,UsuarioId) SELECT Id,UsuarioId FROM inserted; END;
GO
