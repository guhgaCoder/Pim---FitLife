# Guia para o colega responsável pelo banco de dados

## Estado atual
O backend ASP.NET Core 8 usa **Microsoft.Data.Sqlite**. As tabelas `users`, `exercises` e `workouts` são criadas na inicialização em `src/FitLife.Api/Program.cs`. O arquivo `database/schema-sqlserver.sql` é **referência acadêmica**, não é executado pela API. Não é possível simplesmente trocar a connection string para SQL Server sem alterar o código.

## Contrato a preservar
A interface Web chama as rotas descritas em `docs/CONTRATO-API.md`. Ao integrar SQL Server, mantenha os endpoints e os formatos de resposta, especialmente `/api/register`, `/api/login`, `/api/me`, `/api/exercises`, `/api/workouts`, `/api/stats`, `/api/profile`, `/api/admin/summary` e `/api/admin/exercises`.

## Tabelas e relações existentes
- `users`: `id` (PK), `name`, `email` (único), `password` (hash PBKDF2), `role` (`student` ou `admin`), `height`, `weight`, `created_at`.
- `exercises`: `id` (PK), `title`, `category`, `minutes`, `calories`, `description`.
- `workouts`: `id` (PK), `user_id` (FK users), `exercise_id` (FK exercises), `performed_at`.
- `users` 1:N `workouts`; `exercises` 1:N `workouts`.

## Estratégia de integração sugerida
1. Conferir MER, modelo lógico/físico e scripts SQL Server com os requisitos do PIM.
2. Comparar nomes, tipos, restrições e relacionamentos com os campos consumidos pela API.
3. Criar camada de repositórios/serviços e isolar o acesso a dados hoje concentrado em `Program.cs`.
4. Implementar um provedor SQL Server com parâmetros SQL, mantendo os contratos HTTP.
5. Configurar connection string via variável de ambiente/secret manager; **nunca** commitar credenciais.
6. Planejar migração dos dados locais (se necessário) e verificar hashes de senha, chaves e datas.
7. Executar testes de cadastro, login, exercícios, registro de treino, estatísticas e painel admin com o banco novo.
8. Registrar evidências para capítulos 3, 4 e 5 do PIM; incluir MER, modelos, procedures e triggers validados.

## Divisão de trabalho
- Banco: scripts, MER, modelo lógico/físico, procedures, triggers e migrações.
- Backend: repositórios, API, autenticação, validações e integração.
- Web/Mobile: consumir API sem acessar o banco diretamente.

## Observações
Não publicar `fitlife.db` ou dados reais no GitHub. Não há integração SQL Server concluída neste pacote. A versão Mobile nativa ainda é pendente.
