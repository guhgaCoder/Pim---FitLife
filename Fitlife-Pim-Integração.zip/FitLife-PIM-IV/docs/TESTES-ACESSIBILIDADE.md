# Checklist manual — acessibilidade v1.0.3

1. Executar a API e abrir o FitLife; usar Tab para alcançar o link **Pular para o conteúdo** e pressionar Enter.
2. Abrir **Acessibilidade** no menu; ativar **Texto ampliado** e conferir que a interface muda.
3. Ativar **Alto contraste** e conferir legibilidade de cartões, botões e formulários.
4. Ativar **Reduzir animações** e verificar a transição do menu no celular.
5. Recarregar a página e conferir que as preferências foram mantidas.
6. No celular, abrir o menu e fechá-lo; com teclado físico, testar Esc.
7. Com leitor de tela, validar títulos, campos, botões e avisos; registrar problemas encontrados.
8. Na cópia local com VLibras, validar abertura do widget e ausência de sobreposição de controles.

**Status:** checklist proposto; os testes manuais não foram executados neste ambiente.
