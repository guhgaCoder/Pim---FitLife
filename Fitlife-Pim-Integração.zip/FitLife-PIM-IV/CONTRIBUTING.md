# Como colaborar

1. Crie uma branch a partir de `main`, por exemplo `feature/integracao-sqlserver`.
2. Não altere contratos de API sem alinhar com o grupo e atualizar `docs/CONTRATO-API.md`.
3. Nunca envie senhas, tokens, strings de conexão reais ou arquivos `.db`.
4. Rode `dotnet restore` e `dotnet build` em `src/FitLife.Api` antes de abrir um Pull Request.
5. Descreva no Pull Request o que mudou, como testar e se houve mudança de banco de dados.
6. Para alterações no banco, inclua script SQL, instruções de execução e atualização dos diagramas do PIM.
7. Preserve o trabalho local com VLibras: ele não faz parte deste pacote-base; envie seu `index.html` alterado em uma branch própria.
