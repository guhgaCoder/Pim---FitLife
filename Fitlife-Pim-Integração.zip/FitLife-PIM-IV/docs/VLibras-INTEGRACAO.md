# Integração VLibras no FitLife

O widget VLibras foi incluído em `src/FitLife.Api/wwwroot/index.html`, imediatamente antes do fechamento de `body`, conforme o trecho informado pelo integrante.

- Requer acesso à internet e disponibilidade do serviço `vlibras.gov.br`.
- Não substitui textos claros, navegação por teclado, leitores de tela ou testes com usuários.
- Verificar no navegador o carregamento do botão e a tradução, inclusive no celular.
- Não há integração nativa com o Android nesta entrega.

## Teste
1. Execute `dotnet run --project src/FitLife.Api/FitLife.Api.csproj --urls http://localhost:5080` a partir da raiz.
2. Abra `http://localhost:5080` com acesso à internet.
3. Confira o widget VLibras e teste a tradução de um texto da interface.
4. Confira no console do navegador se há erros de carregamento.

## Nota acadêmica
Relaciona-se ao item 2.6 (responsabilidade social, diversidade e inclusão) e ao item 5.8 (integração das disciplinas) do roteiro de capítulos do PIM IV.
