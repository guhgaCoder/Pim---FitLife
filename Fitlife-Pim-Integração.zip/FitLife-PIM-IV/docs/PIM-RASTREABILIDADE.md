# Rastreabilidade PIM IV — situação real
Base: documento de sugestão de capítulos do professor e roteiro didático Mobile Android Java/XML.

| Item acadêmico | Situação no pacote |
|---|---|
| 1 Introdução, objetivos, justificativa, metodologia | A redigir com dados reais do grupo |
| 2 Organização, processos, problemas, inclusão | A documentar conforme empresa fictícia FitLife |
| 3.1 Arquitetura | Web estática → ASP.NET Core API → SQLite; Android ainda não integrado |
| 3.2 Orientação a objetos, camadas | Parcial: DTOs em records; refatorar endpoints em serviços/repositórios |
| 3.3 Aplicação Web | Telas do aluno e painel admin incluídos |
| 3.4 API | Endpoints JSON documentados em CONTRATO-API.md |
| 3.5 Aplicação Mobile | Não entregue: responsabilidade do integrante Mobile; roteiro Android Java/XML permanece como base |
| 4.1–4.5 Dados, MER, lógico, físico | Entidades preliminares; SQL Server físico proposto; MER visual ainda pendente |
| 4.6 Procedures, triggers, scripts | Exemplos SQL Server incluídos; integração com banco final pendente |
| 4.7–4.9 Infraestrutura, cloud, DevOps | Planejamento pendente; execução local descrita |
| 5 Agile, backlog, sprints, Kanban, cronograma | Planejamento inicial abaixo; execução real deve ser registrada pelo grupo |
| 6 Conclusões | Só após implementação e testes do grupo |

## Product backlog sugerido
PB01 Autenticação aluno/admin — implementado em código, não validado em runtime.
PB02 Cadastro e perfil — implementado em código, não validado em runtime.
PB03 Catálogo de treinos — implementado em código, não validado em runtime.
PB04 Registro e evolução — implementado em código, não validado em runtime.
PB05 Conquistas — implementado em código, não validado em runtime.
PB06 Gestão de exercícios — implementado em código, não validado em runtime.
PB07 Integrar banco SQL Server do colega — pendente.
PB08 Integrar Android Java/XML — pendente.
PB09 Testes automatizados, segurança, implantação — pendente.
PB10 MER, diagramas, sprints e relatório acadêmico — pendente.

## Sprints propostas (não realizadas)
Sprint 1: validar execução Web/API e corrigir erros. Sprint 2: refatorar camadas e banco final. Sprint 3: autenticação Mobile e integração. Sprint 4: testes, cloud/DevOps, documentação e apresentação.
