# FitLife PIM IV — Guia passo a passo para o responsável pelo banco de dados

> **Objetivo:** integrar o banco de dados definitivo ao backend ASP.NET Core 8, preservando o funcionamento da aplicação Web e preparando a futura integração com o Android. O projeto atual usa SQLite; o SQL Server ainda **não** está conectado. Este guia se baseia na versão `FitLife-PIM-IV-GitHub-com-VLibras`.

## 1. Preparação do ambiente

Instale **Git**, **.NET SDK 8**, **SQL Server Developer/Express** (ou instância de desenvolvimento autorizada), **SQL Server Management Studio (SSMS)** ou Azure Data Studio/alternativa equivalente, e um editor como VS Code ou Visual Studio. Tenha acesso ao repositório do GitHub como colaborador.

```powershell
git clone https://github.com/USUARIO-DO-GRUPO/FitLife-PIM-IV.git
cd FitLife-PIM-IV
git checkout -b feature/integracao-banco
cd src/FitLife.Api
dotnet restore
dotnet build
dotnet run --urls "http://localhost:5080"
```

Troque `USUARIO-DO-GRUPO` pelo proprietário real. Abra `http://localhost:5080` e verifique a versão inicial **antes** de modificar o código. Pare o servidor com `Ctrl+C`. Não altere a branch `main` diretamente.

## 2. Entenda os arquivos antes de editar

| Arquivo | Para que serve |
|---|---|
| `src/FitLife.Api/Program.cs` | Endpoints, autenticação, inicialização SQLite e consultas SQL atuais |
| `src/FitLife.Api/FitLife.Api.csproj` | Dependências .NET; atualmente contém `Microsoft.Data.Sqlite` |
| `database/schema-sqlserver.sql` | **Modelo SQL Server inicial**; precisa ser revisado e testado |
| `docs/CONTRATO-API.md` | Métodos, rotas e formatos esperados pelo frontend |
| `docs/INTEGRACAO-BANCO.md` | Regras para preservar comportamento e contratos |
| `src/FitLife.Api/wwwroot/app.js` | Frontend que consome a API; evite mudar suas chamadas sem combinar com a equipe |
| `src/FitLife.Api/wwwroot/index.html` | Página com a integração VLibras; não remover |

As tabelas atuais são `users` (alunos/admins), `exercises` (exercícios) e `workouts` (registros de treinos). `users` 1:N `workouts` e `exercises` 1:N `workouts`.

## 3. Entregáveis acadêmicos do banco

Produza na pasta `database/` e/ou `docs/`:

1. **MER (modelo entidade-relacionamento)** com entidades, atributos, cardinalidades e relacionamentos.
2. **Modelo lógico** com tabelas, PK, FK, unicidade e tipos previstos.
3. **Modelo físico SQL Server** com `CREATE TABLE`, `FOREIGN KEY`, `UNIQUE`, `CHECK`, índices e dados de teste sem informações pessoais reais.
4. **Procedures** com caso de uso justificado (por exemplo, registrar treino de modo transacional); demonstre execução.
5. **Triggers** com finalidade definida (por exemplo, auditoria de alteração de exercício), evitando efeitos colaterais não documentados.
6. **Scripts versionados**, ordenados e com instruções para execução e reversão/backup.
7. Evidências: capturas do diagrama, scripts executados, consultas e testes para o relatório do PIM.

**Atenção:** procedures e triggers devem atender aos requisitos do PIM e à lógica aprovada pelo grupo. Não é necessário forçar toda consulta da API a virar procedure.

## 4. Preparar o SQL Server

No SSMS, conecte-se à instância de desenvolvimento e crie uma base de teste, por exemplo:

```sql
IF DB_ID(N'FitLifeDev') IS NULL
    CREATE DATABASE FitLifeDev;
GO
USE FitLifeDev;
GO
```

Revise e execute `database/schema-sqlserver.sql` **somente depois de conferir seu conteúdo**, dependências e compatibilidade. O script é ponto de partida e pode exigir ajustes. Verifique tabelas e relacionamentos no SSMS. Faça backup antes de rodar scripts destrutivos em bases que contenham dados.

## 5. Isolar a persistência antes de trocar o provedor

O `Program.cs` atual mistura endpoints com SQL SQLite. Recomenda-se organizar gradualmente:

```text
src/FitLife.Api/
  Program.cs                 # rotas e configuração
  Data/
    DbConnectionFactory.cs   # criação de conexões SQL Server
    UserRepository.cs        # usuários, login e perfil
    ExerciseRepository.cs    # exercícios
    WorkoutRepository.cs     # treinos, histórico e estatísticas
  Services/                  # regras de negócio, se necessário
```

Essa estrutura é uma **sugestão**, não uma pasta já existente. Antes de substituir cada consulta, registre o resultado esperado do endpoint correspondente. Utilize parâmetros SQL em todos os comandos e transações quando houver operações relacionadas.

## 6. Configuração de conexão segura

Adicione o pacote adequado ao provedor escolhido, por exemplo:

```powershell
cd src/FitLife.Api
dotnet add package Microsoft.Data.SqlClient
```

Ajuste o código para ler `ConnectionStrings:FitLife` da configuração. **Exemplo ilustrativo** de configuração local por user-secrets:

```powershell
dotnet user-secrets init
dotnet user-secrets set "ConnectionStrings:FitLife" "Server=localhost;Database=FitLifeDev;Trusted_Connection=True;TrustServerCertificate=True;"
```

O nome da instância e o método de autenticação podem variar. `TrustServerCertificate=True` só é aceitável para desenvolvimento local controlado; em produção use TLS validado. Não envie `.env`, senhas, connection strings com credenciais, bancos `.db`, backups nem dados reais para o GitHub.

## 7. Migrar as operações da API, uma a uma

Mantenha o contrato descrito em `docs/CONTRATO-API.md`:

| Ordem | Endpoint | O que testar após integrar |
|---|---|---|
| 1 | `POST /api/register` | Cria usuário; e-mail duplicado retorna erro; senha não é salva em texto puro |
| 2 | `POST /api/login` | Login correto/incorreto; sessão e papel do usuário |
| 3 | `GET /api/me` | Retorna usuário logado, sem hash de senha |
| 4 | `PATCH /api/profile` | Atualiza apenas o perfil do próprio usuário |
| 5 | `GET /api/exercises` | Lista exercícios com campos e ordenação esperados |
| 6 | `POST /api/workouts` | Registra treino vinculado ao usuário autenticado |
| 7 | `GET /api/stats` | Histórico, totais, calorias, minutos, sequência e conquistas |
| 8 | `GET /api/admin/summary` | Apenas admin; contagens e lista de alunos |
| 9 | `POST /api/admin/exercises` | Apenas admin; valida e cadastra exercício |
| 10 | `POST /api/logout` | Encerra sessão |

**Diferenças entre bancos a tratar:** `last_insert_rowid()` é específico de SQLite (no SQL Server, considere `OUTPUT INSERTED.id`); `INSERT OR IGNORE` não existe no SQL Server; tipos de datas, `IDENTITY`, tratamento de conflitos, paginação e valores booleanos também exigem revisão. Mantenha o esquema de hash PBKDF2 existente ou planeje migração explícita — não redefina senhas silenciosamente.

## 8. Testes obrigatórios de integração

Execute:

```powershell
dotnet restore
dotnet build
dotnet run --urls "http://localhost:5080"
```

Depois teste no navegador: cadastrar aluno, entrar, abrir exercícios, registrar treino, consultar evolução, editar perfil, sair, entrar como admin e cadastrar exercício. Teste também: e-mail duplicado, senha inválida, acesso de aluno a rota administrativa (deve ser negado) e tentativa de acessar dados de outro usuário. Reinicie o servidor e confira se os dados continuam no SQL Server. Documente o resultado em `docs/TESTES-BANCO.md` (cenário, passos, esperado, obtido, data e evidência).

Para a integração Android futura, **não** forneça acesso direto ao SQL Server: o app Java/XML deverá consumir a API por HTTPS. A autenticação atual é por cookie da Web; autenticação própria para o aplicativo móvel ainda deverá ser projetada e testada.

## 9. Entrega no GitHub

Na raiz do repositório:

```powershell
git status
git add src/FitLife.Api database docs
git commit -m "Integra persistencia SQL Server e documenta modelos"
git push -u origin feature/integracao-banco
```

Abra um **Pull Request** da branch `feature/integracao-banco` para `main`. Na descrição, informe: o que mudou, como configurar o SQL Server, scripts executados, testes realizados, pendências e capturas relevantes. Aguarde revisão do grupo antes do merge. Não inclua arquivos secretos ou dados pessoais no commit.

## 10. Critérios de conclusão (checklist)

- [ ] MER, modelo lógico e físico entregues e coerentes entre si.
- [ ] Scripts SQL Server reproduzíveis em base limpa.
- [ ] Procedures e triggers justificadas e testadas.
- [ ] Aplicação executa com SQL Server, sem dependência operacional do SQLite.
- [ ] Contratos da API e permissões preservados.
- [ ] Login, cadastro, perfil, exercícios, treinos, evolução e admin testados.
- [ ] Credenciais fora do Git; sem dados reais no repositório.
- [ ] README atualizado com instruções de execução.
- [ ] Evidências acadêmicas e relatório de testes incluídos.
- [ ] Pull Request aberto, revisado e aprovado.

## 11. Comunicação com o grupo

Antes de começar, confirme com o responsável pelo backend: versão/edição do SQL Server, nomes definitivos das entidades, estratégia de migrations e se será necessário migrar usuários de SQLite. Ao concluir cada conjunto de endpoints, comunique a branch/commit e os testes. **Não altere a interface, o VLibras ou a futura aplicação Android sem alinhamento.**
