# Contrato de integração FitLife v1
Base URL local: `http://localhost:5080`. JSON UTF-8. Autenticação web por cookie HttpOnly (não é token para Android). Campos e rotas são contratos provisórios, sujeitos à validação com o banco de dados do colega.

| Método | Rota | Acesso | Corpo / resultado |
|---|---|---|---|
| POST | /api/register | público | `{ "name":"Ana", "email":"ana@exemplo.com", "password":"senha-forte" }` |
| POST | /api/login | público | `{ "email":"ana@exemplo.com", "password":"senha-forte" }` |
| POST | /api/logout | autenticado | encerra sessão |
| GET | /api/me | público | `{ "user": null }` ou usuário sem senha |
| GET | /api/exercises | autenticado | `{ "items": [...] }` |
| POST | /api/workouts | autenticado | `{ "exercise_id": 1 }` |
| GET | /api/stats | autenticado | total, minutes, calories, streak, history, achievements |
| PATCH | /api/profile | autenticado | `{ "name":"Ana", "height":170, "weight":65 }` |
| GET | /api/admin/summary | admin | students, workouts, exercises, users |
| POST | /api/admin/exercises | admin | `{ "title":"Treino", "category":"Força", "minutes":30, "calories":150, "description":"..." }` |

## Integração Android
A implementação atual autentica via cookie, adequada ao portal web. **Não conectar o Android diretamente ao banco.** Para integração mobile, implementar autenticação de API adequada ao Android (por exemplo JWT com refresh token e armazenamento seguro), CORS restrito quando aplicável, HTTPS e documentação OpenAPI. O roteiro de Java/XML do PIM continua como responsabilidade da equipe Mobile.

## Integração do banco do colega
1. Receber MER, SGBD, DDL SQL, chaves, tipos, regras de negócio e scripts de procedures/triggers.
2. Criar uma camada de repositórios para desacoplar endpoints do SQL atual (o MVP ainda contém SQL nos endpoints).
3. Criar mapeamento entre tabelas atuais `users`, `exercises`, `workouts` e entidades fornecidas.
4. Adicionar configuração de conexão e migrations versionadas, sem apagar dados existentes.
5. Testar cadastro, login, treino, perfil, estatísticas e autorização antes da troca definitiva.
6. Nunca armazenar senhas em texto simples nem reutilizar hashes incompatíveis sem estratégia de migração.
